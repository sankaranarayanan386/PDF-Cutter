package edu.pdfcutter.Data.parsePDF;

import java.io.File;
import java.io.IOException;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.encryption.InvalidPasswordException;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.springframework.stereotype.Component;


@Component
public class PdfParser {
	public void pdfrader(String infileName,String fileName,String[] pages) throws InvalidPasswordException, IOException {
		try {
			int fromPage=Integer.parseInt(pages[0]);
			int toPage=Integer.parseInt(pages[1]);
			System.out.println("Reading " + infileName);
			//PdfReader reader = new PdfReader(infileName);
			/*int totalPages = reader.getNumberOfPages();*/
			int toal=(toPage-fromPage)+1;
			int splittedPageSize = (Integer.parseInt(pages[1])-Integer.parseInt(pages[0]));
			int split=0;
			File file = new File(infileName);
			File dir = new File(infileName.
                    substring(0, infileName.indexOf(".pdf"))
                    + "//");
			if(!dir.isDirectory()) {
				dir.mkdir();
			}else {
				System.out.println(infileName.
	                    substring(0, infileName.indexOf(".pdf"))
	                    + "/"+" folder is already created....skipping folder creation........");
			}
		
			String outFile = infileName.
                    substring(0, infileName.indexOf(".pdf"))
                    + "//" + fileName + ".pdf";
			
			PDDocument originalDocment=PDDocument.load(file);
			PDDocument document = new PDDocument();
			 for (int pageNum = fromPage; pageNum <= toPage; pageNum ++ ) {
				 PDPage page = new PDPage();
				 page= originalDocment.getPage(pageNum);
				 document.addPage(page);
				 
				 /*for( PDPage page1 : originalDocment.getPages() )
			      {
					 
			        page=page1;
			        document.addPage(page);
			        
			      }*/
				  
				
				 /*
	                split++;
	                String outFile = infileName.
	                        substring(0, infileName.indexOf(".pdf"))
	                        + "//" + fileName + ".pdf";
	                Document document = new Document(reader.getPageSizeWithRotation(1));
	                PdfCopy writer = new PdfCopy(document, new FileOutputStream(
	                        outFile));
	                document.open();
	                int tempPageCount = 0;
	                for (int offset = tempPageCount; offset <= splittedPageSize
	                        && (offset) <= toal;offset++,tempPageCount++) {
	                    PdfImportedPage page = writer.getImportedPage(reader,
	                            pageNum + offset);
	                    writer.addPage(page);
	                    pageNum=offset;
	                }
	                document.close();
	                writer.close();
			 */}
			 document.save(outFile);
			 document.close();
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
				

}

}
