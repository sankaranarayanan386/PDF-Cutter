package edu.pdfcutter.Data.Reader;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.springframework.stereotype.Component;

@Component
public class ExcelParser {
	public String fileName = "";
	public String pages;
	public String[] pagesplit = {"",""};
	public String pageTo;

	public HashMap<String, String[]> excelReader(String path) throws IOException, InvalidFormatException {

		
		HashMap<String,String[]> listofFiles= new HashMap<String,String[]>();

		Workbook workbook = WorkbookFactory.create(new File(path));
		System.out.println(path);
		System.out.println("Workbook has " + workbook.getNumberOfSheets() + " Sheets : ");
		workbook.forEach(sheet -> {
			System.out.println("=> " + sheet.getSheetName());
		});
		Sheet sheet = workbook.getSheetAt(0);
		DataFormatter dataFormatter = new DataFormatter();
		sheet.forEach(row -> {
			row.forEach(cell -> {
				String cellValue = dataFormatter.formatCellValue(cell);
				if (cellValue.contains("|")) {
					pages = cellValue;
					pagesplit = pages.split("\\|");
					/*System.out.println();
					System.out.println("pages " + pages);
					System.out.println();
					System.out.println("pageSplit " + pagesplit[0] + " second page " + pagesplit[1]);*/
				} else {
					fileName = cellValue.toLowerCase();
					/*System.out.println("fileName " + fileName);
					System.out.println();*/
				}

			});
			listofFiles.put(fileName,pagesplit); 
		});

		listofFiles.entrySet().forEach(entry->{
			String key1,key2="";
			key1=entry.getValue()[0];
			key2=entry.getValue()[1];
			    System.out.println(entry.getKey() + " " + key1 + " " + key2);  
			 });
		workbook.close();
return listofFiles;
	}
}
