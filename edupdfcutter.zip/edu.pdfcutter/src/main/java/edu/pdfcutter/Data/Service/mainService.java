/**
 * 
 */
package edu.pdfcutter.Data.Service;

import java.io.IOException;
import java.util.HashMap;
import java.util.Scanner;
import java.util.Set;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

import edu.pdfcutter.Data.Reader.ExcelParser;
import edu.pdfcutter.Data.parsePDF.PdfParser;

public class mainService {

	/*@Autowired
	ExcelParser excelparser;
	
	@Autowired
	PdfParser pdfparser;*/
	
	ExcelParser excelparse = new ExcelParser();
	PdfParser pdfparser = new PdfParser();
	
	public static void main(String[] args) throws InvalidFormatException, IOException {
	
		mainService service = new mainService();
		java.util.logging.Logger
	    .getLogger("org.apache.pdfbox").setLevel(java.util.logging.Level.OFF);

		/* "C://Users//668376//Desktop//excelparsertest.xlsx";*/
		 /*"C://Users//668376//Desktop//invoice1.pdf";*/
		Scanner input = new Scanner(System.in);
		System.out.println("Enter the Excel Sheet file path upto file extension...");
		String excelFilePath =input.nextLine();
		System.out.println("Enter the PDf file's Path upto file extension...");
		String infilepath =input.nextLine();
		input.close();
/*		System.out.println("pat =" +excelFilePath);
*/		HashMap<String, String[]> listofFiles =service.executepp(excelFilePath,infilepath);
		
		System.out.println("ProgramCompleted Successfully");
	}
	public HashMap<String,String[]> executepp(String excelFilePath,String infilepath) throws InvalidFormatException, IOException{
		
		HashMap<String, String[]> listofFiles = excelparse.excelReader(excelFilePath);
		System.out.println("path =" +excelFilePath);
		
		Set<String> filenames=listofFiles.keySet();
		for (String filename : filenames) {
			pdfparser.pdfrader(infilepath,filename,listofFiles.get(filename));
		}
		
		
		return listofFiles;
		
		
	}
	

}
